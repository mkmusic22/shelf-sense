# ShelfSense - A Local First Grocery Tracking App

a project three of us did for our class 12 cs project. we rushed a lot with this project.

## Flet prototype

Run `flet run main.py` to launch the app. The home screen prompts signed-out users
to sign up or log in, the Add Item tab provides an inventory form, and Settings
shows the signed-in username and light, dark, and system theme choices.

This prototype identifies accounts by username only and does not provide 
password-based authentication.

this is not reflective of my actual coding practices. a good portion of the code (20%) was ai generated because we weren't given enough time. but I might just look back at this and redo the entire code in Jetpack compose. (i dont like python and sql anyways ;-; i prefer java + json. I know those two dont usually go together, but if it works, it works.)

this project messed up with my computer so much. am genuinely not using python anymore ;-;

this is actually an interesting concept if i actually got time in school to implement.